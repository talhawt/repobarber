<?php
/**
 * Dosya: admin/index.php
 * Amaç: Admin paneli ana sayfası (Dashboard). 
 * GÜVENLİK: PHP Session kontrolü eklenmiştir.
 */

// 1. OTURUM KONTROLÜ (En üstte olmalı)
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Giriş yapılmamışsa ana sayfaya ve giriş modalına yönlendir
    header("Location: ../index.html?access=denied");
    exit;
}

include '../api/db.php';

// Bugünün tarihi
$today = date('Y-m-d');

// --- İSTATİSTİKLERİ ÇEK ---
$stats_query = "
    SELECT 
        (SELECT COUNT(*) FROM randevular) as total_appointments,
        (SELECT COUNT(*) FROM randevular WHERE randevu_tarihi = '$today') as today_appointments,
        (SELECT COUNT(*) FROM users) as total_users,
        (SELECT COUNT(*) FROM bulten) as total_subscribers
";
$stats_result = $conn->query($stats_query);

// Sorgu başarılı mı kontrol et
if ($stats_result) {
    $stats = $stats_result->fetch_assoc();
} else {
    // Eğer bulten tablosu yoksa veya sorgu hatası varsa varsayılan değerler ata
    $stats = [
        'total_appointments' => 0,
        'today_appointments' => 0,
        'total_users' => 0,
        'total_subscribers' => 0
    ];
}

// --- SON RANDEVULARI ÇEK ---
$sql = "SELECT * FROM randevular ORDER BY randevu_tarihi DESC, randevu_saati ASC LIMIT 10";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Berber Yönetim Paneli</title>
    <!-- İkonlar ve Fontlar -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700&family=Playfair+Display:ital,wght@0,700;1,400&display=swap" rel="stylesheet">
    
    <!-- Ortak CSS Dosyasına Bağlantı -->
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>

    <!-- YAN MENÜ (SIDEBAR) -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h2>BERBER</h2>
        </div>
        <ul class="sidebar-menu">
            <li><a href="index.php" class="active"><i class="fa-solid fa-gauge"></i> <span>Panel</span></a></li>
            <li><a href="randevular.php"><i class="fa-solid fa-calendar-check"></i> <span>Randevular</span></a></li>
            <li><a href="kullanicilar.php"><i class="fa-solid fa-users"></i> <span>Kullanıcılar</span></a></li>
            <li><a href="bulten.php"><i class="fa-solid fa-envelope-open-text"></i> <span>E-Bülten</span></a></li>
            <li><a href="ayarlar.php"><i class="fa-solid fa-gear"></i> <span>Site Ayarları</span></a></li>
            <li style="margin-top:auto; border-top:1px solid #333;">
                <a href="../index.html" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> <span>Siteye Git</span></a>
            </li>
        </ul>
    </aside>

    <!-- ANA İÇERİK (MAIN CONTENT) -->
    <main class="main-content">
        <div class="admin-header">
            <div>
                <h1>Dashboard</h1>
                <p>Hoş geldiniz, <strong><?php echo htmlspecialchars($_SESSION['admin_user'] ?? 'Yönetici'); ?></strong>. İşletme durumu aşağıdadır.</p>
            </div>
            <!-- Çıkış Butonu (logout.php dosyasına yönlendirir) -->
            <a href="logout.php" onclick="return confirm('Oturum kapatılsın mı?')" class="btn" style="background:#222; color:#fff; border:1px solid #444;">
                <i class="fa-solid fa-right-from-bracket"></i> Güvenli Çıkış
            </a>
        </div>

        <!-- İSTATİSTİK KARTLARI -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-calendar-day"></i></div>
                <div class="stat-info">
                    <h3><?php echo $stats['today_appointments'] ?? 0; ?></h3>
                    <p>Bugünküler</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-list-check"></i></div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_appointments'] ?? 0; ?></h3>
                    <p>Toplam Randevu</p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-users"></i></div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_users'] ?? 0; ?></h3>
                    <p>Müşteriler</p>
                </div>
            </div>
            <!-- Abone Sayısı Kartı -->
            <div class="stat-card">
                <div class="stat-icon"><i class="fa-solid fa-envelope"></i></div>
                <div class="stat-info">
                    <h3><?php echo $stats['total_subscribers'] ?? 0; ?></h3>
                    <p>Bülten Abonesi</p>
                </div>
            </div>
        </div>

        <!-- SON RANDEVULAR TABLOSU -->
        <div class="table-container">
            <div class="table-header">
                <h3 style="margin:0; color:#fff; font-family:'Playfair Display', serif;">Son 10 Hareket</h3>
                <div style="display:flex; gap:10px;">
                    <a href="randevular.php" class="btn" style="padding:10px 20px; font-size:0.85rem;">Tümünü Gör</a>
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Müşteri</th>
                        <th>İletişim</th>
                        <th>Tarih & Saat</th>
                        <th>Hizmet</th>
                        <th>Durum</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td>
                                    <div style="font-weight:bold; color:#fff;"><?php echo htmlspecialchars($row['ad_soyad']); ?></div>
                                    <?php if(!empty($row['user_id'])): ?>
                                        <span class="user-type"><i class="fa-solid fa-check-circle"></i> Üye</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $row['telefon']; ?></td>
                                <td>
                                    <?php echo date("d.m.Y", strtotime($row['randevu_tarihi'])); ?>
                                    <span style="color:#777; margin-left:5px;"><?php echo $row['randevu_saati']; ?></span>
                                </td>
                                <!-- Hizmet Sütunu -->
                                <td style="color:#c79c60; font-weight:600;"><?php echo $row['hizmet_turu'] ?? 'Genel Hizmet'; ?></td>
                                <td><span class="status-badge">Onaylı</span></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" style="text-align:center; padding:40px; color:#666;">Henüz hiç randevu kaydı bulunmamaktadır.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

</body>
</html>