<?php
/**
 * Dosya: admin/ayarlar.php
 * Amaç: Site genel ayarlarını, hizmet kartlarını, manifesto ve harita bilgilerini yöneten merkezi panel.
 * GÜVENLİK: PHP Session kontrolü eklenmiştir.
 */

// 1. OTURUM KONTROLÜ (Güvenlik Kapısı)
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Giriş yapılmamışsa ana sayfaya ve giriş modalına yönlendir
    header("Location: ../index.html?access=denied");
    exit;
}

include '../api/db.php';

// 2. Genel Ayarları Çek
$sql_ayarlar = "SELECT * FROM ayarlar WHERE id=1";
$res_ayarlar = $conn->query($sql_ayarlar);
$ayarlar = $res_ayarlar->fetch_assoc() ?: [];

// 3. Hizmetleri Çek
$sql_hizmetler = "SELECT * FROM hizmetler ORDER BY sira ASC";
$res_hizmetler = $conn->query($sql_hizmetler);
$hizmetler = [];
while($row = $res_hizmetler->fetch_assoc()) {
    $hizmetler[] = $row;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Ayarları | Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700&family=Playfair+Display:ital,wght@0,700;1,400&display=swap" rel="stylesheet">
    <!-- Ortak Admin CSS -->
    <link rel="stylesheet" href="css/admin.css">
    <style>
        .service-item {
            border: 1px solid var(--border-color);
            padding: 20px;
            border-radius: var(--radius-sm);
            background: rgba(255,255,255,0.02);
            margin-bottom: 20px;
            position: relative;
        }
        .service-item:hover { border-color: var(--main-color); }
        .service-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
        .remove-service { color: #dc3545; cursor: pointer; font-size: 1.2rem; }
    </style>
</head>
<body>

    <!-- YAN MENÜ (SIDEBAR) -->
    <aside class="sidebar">
        <div class="sidebar-header"><h2>BERBER</h2></div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fa-solid fa-gauge"></i> <span>Panel</span></a></li>
            <li><a href="randevular.php"><i class="fa-solid fa-calendar-check"></i> <span>Randevular</span></a></li>
            <li><a href="kullanicilar.php"><i class="fa-solid fa-users"></i> <span>Kullanıcılar</span></a></li>
            <li><a href="bulten.php"><i class="fa-solid fa-envelope-open-text"></i> <span>E-Bülten</span></a></li>
            <li><a href="ayarlar.php" class="active"><i class="fa-solid fa-gear"></i> <span>Ayarlar</span></a></li>
            <li style="margin-top:auto; border-top:1px solid #333;">
                <a href="../index.html" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> <span>Siteye Git</span></a>
            </li>
        </ul>
    </aside>

    <!-- ANA İÇERİK -->
    <main class="main-content">
        <div class="admin-header">
            <div>
                <h1>Yönetim Paneli</h1>
                <p>Web sitenizi ve sunduğunuz hizmetleri buradan yapılandırın.</p>
            </div>
            <!-- GÜVENLİK: Çıkış Butonu -->
            <a href="logout.php" onclick="return confirm('Oturum kapatılsın mı?')" class="btn" style="background:#222; color:#fff; border:1px solid #444;">
                <i class="fa-solid fa-right-from-bracket"></i> Güvenli Çıkış
            </a>
        </div>
        
        <!-- GENEL AYARLAR -->
        <div class="form-card">
            <h3 class="form-title">Genel & Hero Bölümü</h3>
            <div class="form-row">
                <div class="form-group">
                    <label>Site Başlığı:</label>
                    <input type="text" id="site_basligi" value="<?php echo htmlspecialchars($ayarlar['site_basligi'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>Ana Slogan:</label>
                    <input type="text" id="hero_baslik" value="<?php echo htmlspecialchars($ayarlar['hero_baslik'] ?? ''); ?>">
                </div>
            </div>
            <div class="form-group">
                <label>Alt Açıklama:</label>
                <input type="text" id="hero_alt" value="<?php echo htmlspecialchars($ayarlar['hero_alt'] ?? ''); ?>">
            </div>
        </div>

        <!-- HİZMET YÖNETİMİ -->
        <div class="form-card">
            <h3 class="form-title">Hizmetlerimiz (Kartlar)</h3>
            <p style="color:#777; margin-bottom:20px; font-size:0.9rem;">Ana sayfadaki hizmet kartlarını burada düzenleyebilirsiniz.</p>
            
            <div id="services-list">
                <?php foreach($hizmetler as $h): ?>
                <div class="service-item" data-id="<?php echo $h['id']; ?>">
                    <div class="service-header">
                        <strong style="color:var(--main-color)">Hizmet #<?php echo $h['id']; ?></strong>
                        <i class="fa-solid fa-trash-can remove-service" onclick="this.parentElement.parentElement.remove()"></i>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Başlık:</label>
                            <input type="text" class="h-baslik" value="<?php echo htmlspecialchars($h['baslik']); ?>">
                        </div>
                        <div class="form-group">
                            <label>Fiyat Etiketi:</label>
                            <input type="text" class="h-fiyat" value="<?php echo htmlspecialchars($h['fiyat']); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Kısa Açıklama:</label>
                        <input type="text" class="h-aciklama" value="<?php echo htmlspecialchars($h['aciklama']); ?>">
                    </div>
                    <div class="form-group">
                        <label>Özellikler (Virgülle ayırın):</label>
                        <textarea class="h-ozellikler" style="height:60px;"><?php echo htmlspecialchars($h['ozellikler']); ?></textarea>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- MANİFESTO AYARLARI -->
        <div class="form-card">
            <h3 class="form-title">Manifesto (Hakkımızda)</h3>
            <div class="form-group">
                <label>Manifesto Başlığı:</label>
                <input type="text" id="manifesto_baslik" value="<?php echo htmlspecialchars($ayarlar['manifesto_baslik'] ?? ''); ?>" placeholder="Örn: Vizyonumuz & Tutkumuz">
            </div>
            <div class="form-group">
                <label>Manifesto Metni:</label>
                <textarea id="manifesto_metin" style="height:120px;" placeholder="İşletme felsefenizi buraya yazın..."><?php echo htmlspecialchars($ayarlar['manifesto_metin'] ?? ''); ?></textarea>
            </div>
            <div class="form-group">
                <label>Manifesto Görsel URL:</label>
                <input type="text" id="manifesto_resim" value="<?php echo htmlspecialchars($ayarlar['manifesto_resim'] ?? ''); ?>" placeholder="https://resim-linki.com/gorsel.jpg">
            </div>
        </div>

        <!-- İLETİŞİM BİLGİLERİ -->
        <div class="form-card">
            <h3 class="form-title">İletişim & Sosyal Medya</h3>
            <div class="form-row">
                <div class="form-group"><label>Adres:</label><input type="text" id="adres" value="<?php echo htmlspecialchars($ayarlar['adres'] ?? ''); ?>"></div>
                <div class="form-group"><label>İlçe/Şehir:</label><input type="text" id="adres_ilce" value="<?php echo htmlspecialchars($ayarlar['adres_ilce'] ?? ''); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Telefon:</label><input type="text" id="telefon" value="<?php echo htmlspecialchars($ayarlar['telefon'] ?? ''); ?>"></div>
                <div class="form-group"><label>E-Posta:</label><input type="text" id="email_iletisim" value="<?php echo htmlspecialchars($ayarlar['email_iletisim'] ?? ''); ?>"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Instagram:</label><input type="text" id="instagram" value="<?php echo htmlspecialchars($ayarlar['instagram'] ?? ''); ?>"></div>
                <div class="form-group"><label>Facebook:</label><input type="text" id="facebook_url" value="<?php echo htmlspecialchars($ayarlar['facebook_url'] ?? ''); ?>"></div>
            </div>
            <div class="form-group">
                <label>Çalışma Saatleri (Her satıra bir gün):</label>
                <textarea id="calisma_saatleri" style="height:100px;"><?php echo htmlspecialchars($ayarlar['calisma_saatleri'] ?? ''); ?></textarea>
            </div>
        </div>

        <!-- HARİTA AYARLARI -->
        <div class="form-card">
            <h3 class="form-title">Konum (Google Maps)</h3>
            <div class="form-group">
                <label>Google Maps Iframe Kodu:</label>
                <textarea id="harita_iframe" style="height:100px;" placeholder='<iframe src="https://www.google.com/maps/embed?..." ...></iframe>'><?php echo htmlspecialchars($ayarlar['harita_iframe'] ?? ''); ?></textarea>
                <small style="color:#777;">Google Haritalar > Paylaş > Harita Yerleştir kısmındaki tüm kodu buraya yapıştırın.</small>
            </div>
        </div>

        <!-- RENKLER -->
        <div class="form-card">
            <h3 class="form-title">Görünüm</h3>
            <div class="form-row color-group">
                <div class="form-group"><label>Ana Renk:</label><input type="color" id="ana_renk" value="<?php echo $ayarlar['ana_renk'] ?? '#c79c60'; ?>"></div>
                <div class="form-group"><label>Arka Plan:</label><input type="color" id="arka_plan" value="<?php echo $ayarlar['arka_plan'] ?? '#1a1a1a'; ?>"></div>
            </div>
        </div>

        <button onclick="kaydetTumunu()" class="save-btn"><i class="fa-solid fa-save"></i> TÜMÜNÜ KAYDET VE YAYINLA</button>
        <br><br>
    </main>

<script>
    async function kaydetTumunu() {
        const btn = document.querySelector('.save-btn');
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> İşleniyor...';

        // 1. Genel Ayarları Topla
        const ayarlar = {
            site_basligi: document.getElementById('site_basligi').value,
            hero_baslik: document.getElementById('hero_baslik').value,
            hero_alt: document.getElementById('hero_alt').value,
            
            manifesto_baslik: document.getElementById('manifesto_baslik').value,
            manifesto_metin: document.getElementById('manifesto_metin').value,
            manifesto_resim: document.getElementById('manifesto_resim').value,

            adres: document.getElementById('adres').value,
            adres_ilce: document.getElementById('adres_ilce').value,
            telefon: document.getElementById('telefon').value,
            email_iletisim: document.getElementById('email_iletisim').value,
            instagram: document.getElementById('instagram').value,
            facebook_url: document.getElementById('facebook_url').value,
            calisma_saatleri: document.getElementById('calisma_saatleri').value,

            harita_iframe: document.getElementById('harita_iframe').value,

            ana_renk: document.getElementById('ana_renk').value,
            arka_plan: document.getElementById('arka_plan').value
        };

        // 2. Hizmetleri Topla
        const hizmetler = [];
        document.querySelectorAll('.service-item').forEach((item, index) => {
            hizmetler.push({
                id: item.getAttribute('data-id'),
                baslik: item.querySelector('.h-baslik').value,
                fiyat: item.querySelector('.h-fiyat').value,
                ikon: "fa-solid fa-scissors", 
                aciklama: item.querySelector('.h-aciklama').value,
                ozellikler: item.querySelector('.h-ozellikler').value,
                sira: index + 1
            });
        });

        try {
            // Ayarları Kaydet
            const res1 = await fetch('../api/ayarlar.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify(ayarlar)
            });
            const data1 = await res1.json();

            // Hizmetleri Kaydet
            const res2 = await fetch('../api/hizmetleri_guncelle.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ hizmetler: hizmetler })
            });
            const data2 = await res2.json();

            if(data1.status === 'success' && data2.status === 'success') {
                alert("✅ Tüm ayarlar, manifesto ve harita başarıyla güncellendi!");
                location.reload();
            } else {
                alert("❌ Bir hata oluştu. Lütfen tekrar deneyin.");
            }
        } catch (err) {
            alert("Bağlantı hatası!");
        } finally {
            btn.disabled = false;
            btn.innerHTML = '<i class="fa-solid fa-save"></i> TÜMÜNÜ KAYDET VE YAYINLA';
        }
    }
</script>

</body>
</html>