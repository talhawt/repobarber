<?php
/**
 * Dosya: admin/bulten.php
 * Amaç: E-Bülten abonelerini listeler ve toplu mail gönderimi sağlar.
 * GÜVENLİK: PHP Session kontrolü eklenmiştir.
 */

// 1. OTURUM KONTROLÜ
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Giriş yapılmamışsa ana sayfaya yönlendir
    header("Location: ../index.html?access=denied");
    exit;
}

include '../api/db.php';

// Silme İşlemi
if(isset($_GET['sil_id'])) {
    $id = intval($_GET['sil_id']);
    $conn->query("DELETE FROM bulten WHERE id=$id");
    header("Location: bulten.php");
    exit;
}

// Aboneleri Çek
$sql = "SELECT * FROM bulten ORDER BY kayit_tarihi DESC";
$result = $conn->query($sql);
$total_subs = $result->num_rows;
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Bülten Yönetimi | Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700&family=Playfair+Display:ital,wght@0,700;1,400&display=swap" rel="stylesheet">
    <!-- Ortak Admin CSS -->
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>

    <!-- YAN MENÜ (SIDEBAR) -->
    <aside class="sidebar">
        <div class="sidebar-header"><h2>BERBER</h2></div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fa-solid fa-gauge"></i> <span>Panel</span></a></li>
            <li><a href="randevular.php"><i class="fa-solid fa-calendar-check"></i> <span>Randevular</span></a></li>
            <li><a href="kullanicilar.php"><i class="fa-solid fa-users"></i> <span>Kullanıcılar</span></a></li>
            <li><a href="bulten.php" class="active"><i class="fa-solid fa-envelope-open-text"></i> <span>E-Bülten</span></a></li>
            <li><a href="ayarlar.php"><i class="fa-solid fa-gear"></i> <span>Ayarlar</span></a></li>
            <li style="margin-top:auto; border-top:1px solid #333;">
                <a href="../index.html" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> <span>Siteye Git</span></a>
            </li>
        </ul>
    </aside>

    <!-- ANA İÇERİK -->
    <main class="main-content">
        <div class="admin-header">
            <div>
                <h1>E-Bülten Yönetimi</h1>
                <p>Abonelerinize toplu e-posta gönderin ve listeyi yönetin.</p>
            </div>
            <!-- GÜVENLİK: Çıkış Butonu -->
            <a href="logout.php" onclick="return confirm('Oturum kapatılsın mı?')" class="btn" style="background:#222; color:#fff; border:1px solid #444;">
                <i class="fa-solid fa-right-from-bracket"></i> Güvenli Çıkış
            </a>
        </div>
        
        <div style="display:flex; gap:30px; flex-wrap: wrap;">
            
            <!-- SOL KOLON: ABONE LİSTESİ -->
            <div style="flex:1; min-width:350px;">
                <div class="table-container">
                    <div class="table-header">
                        <h3 style="margin:0; color:#fff; font-family:'Playfair Display';">Aboneler (<?php echo $total_subs; ?>)</h3>
                    </div>
                    <div style="max-height: 600px; overflow-y: auto;">
                        <table>
                            <thead>
                                <tr>
                                    <th>E-Posta Adresi</th>
                                    <th>Kayıt Tarihi</th>
                                    <th>İşlem</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($result->num_rows > 0): ?>
                                    <?php while($row = $result->fetch_assoc()): ?>
                                        <tr>
                                            <td style="font-weight:bold; color:#fff;"><?php echo htmlspecialchars($row['email']); ?></td>
                                            <td style="color:#777; font-size:0.85rem;"><?php echo date("d.m.Y H:i", strtotime($row['kayit_tarihi'])); ?></td>
                                            <td>
                                                <a href="?sil_id=<?php echo $row['id']; ?>" class="action-btn delete-btn" onclick="return confirm('Bu aboneyi silmek istediğine emin misin?')" title="Abone Sil">
                                                    <i class="fa-solid fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                <?php else: ?>
                                    <tr><td colspan="3" style="text-align:center; padding:50px; color:#666;">Henüz kayıtlı bir abone bulunmuyor.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- SAĞ KOLON: MAİL GÖNDERME FORMU -->
            <div style="flex:1; min-width:350px;">
                <div class="form-card">
                    <h3 class="form-title">Toplu Mail Gönder</h3>
                    <p style="color:#777; margin-bottom:20px; font-size:0.9rem;">
                        Tüm bülten abonelerine HTML formatında duyuru gönderir.
                    </p>

                    <div class="form-group">
                        <label>Konu Başlığı:</label>
                        <input type="text" id="mailSubject" placeholder="Örn: Hafta Sonu Fırsatı!">
                    </div>

                    <div class="form-group" style="margin-top:15px;">
                        <label>Mesaj İçeriği (HTML Destekli):</label>
                        <textarea id="mailMessage" style="height:250px;" placeholder="Merhaba,<br><br>Size özel yeni kampanyalarımız..."></textarea>
                    </div>

                    <button onclick="sendBulkMail()" class="save-btn" id="btnSend" style="margin-top:20px;">
                        <i class="fa-solid fa-paper-plane"></i> GÖNDERİMİ BAŞLAT
                    </button>
                </div>
            </div>

        </div>
    </main>

    <script>
        function sendBulkMail() {
            const subject = document.getElementById('mailSubject').value;
            const message = document.getElementById('mailMessage').value;
            const btn = document.getElementById('btnSend');

            if(!subject || !message) { 
                alert("Lütfen konu ve mesaj içeriği girin."); 
                return; 
            }
            
            if(!confirm("Kayıtlı tüm abonelere mail gönderilecek. Devam edilsin mi?")) return;

            btn.disabled = true;
            btn.style.opacity = "0.7";
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Gönderiliyor...';

            fetch('../api/send_bulk_mail.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ subject: subject, message: message })
            })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    alert("✅ " + data.message);
                    document.getElementById('mailSubject').value = "";
                    document.getElementById('mailMessage').value = "";
                } else {
                    alert("❌ " + data.message);
                }
            })
            .catch(err => {
                alert("Sunucuyla bağlantı kurulamadı.");
            })
            .finally(() => {
                btn.disabled = false;
                btn.style.opacity = "1";
                btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> GÖNDERİMİ BAŞLAT';
            });
        }
    </script>

</body>
</html>