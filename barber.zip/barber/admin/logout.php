<?php
/**
 * Dosya: admin/logout.php
 * Amaç: Admin oturumunu tamamen sonlandırır ve kullanıcıyı ana sayfaya yönlendirir.
 */

// Oturumu başlat
session_start();

// Tüm session değişkenlerini temizle
session_unset();

// Oturumu tamamen yok et
session_destroy();

// Kullanıcıyı ana sayfadaki giriş modalına veya doğrudan ana sayfaya yönlendir
header("Location: ../index.html");
exit;
?>