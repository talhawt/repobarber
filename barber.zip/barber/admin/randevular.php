<?php
/**
 * Dosya: admin/randevular.php
 * GÜVENLİK: PHP Session kontrolü eklendi.
 */
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: ../index.html?access=denied");
    exit;
}

include '../api/db.php';

// Silme İşlemi
if(isset($_GET['sil_id'])) {
    $id = intval($_GET['sil_id']);
    $conn->query("DELETE FROM randevular WHERE id=$id");
    header("Location: randevular.php");
    exit;
}

// Tüm Randevuları Çek
$sql = "SELECT * FROM randevular ORDER BY randevu_tarihi DESC, randevu_saati ASC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Randevu Yönetimi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>

    <aside class="sidebar">
        <div class="sidebar-header"><h2>BERBER</h2></div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fa-solid fa-gauge"></i> <span>Panel</span></a></li>
            <li><a href="randevular.php" class="active"><i class="fa-solid fa-calendar-check"></i> <span>Randevular</span></a></li>
            <li><a href="kullanicilar.php"><i class="fa-solid fa-users"></i> <span>Kullanıcılar</span></a></li>
            <li><a href="bulten.php"><i class="fa-solid fa-envelope-open-text"></i> <span>E-Bülten</span></a></li>
            <li><a href="ayarlar.php"><i class="fa-solid fa-gear"></i> <span>Site Ayarları</span></a></li>
            <li style="margin-top:auto; border-top:1px solid #333;">
                <a href="../index.html" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> <span>Siteye Git</span></a>
            </li>
        </ul>
    </aside>

    <main class="main-content">
        <div class="admin-header">
            <div>
                <h1>Tüm Randevular</h1>
                <p>Bekleyen ve tamamlanan tüm randevu kayıtları.</p>
            </div>
            <a href="logout.php" class="btn" style="background:#222; color:#fff; border:1px solid #444;">
                <i class="fa-solid fa-right-from-bracket"></i> Güvenli Çıkış
            </a>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Müşteri</th>
                        <th>İletişim</th>
                        <th>Hizmet</th>
                        <th>Tarih & Saat</th>
                        <th>İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td>#<?php echo $row['id']; ?></td>
                                <td>
                                    <div style="font-weight:bold; color:#fff;"><?php echo htmlspecialchars($row['ad_soyad']); ?></div>
                                    <?php if(!empty($row['user_id'])): ?>
                                        <span class="user-type"><i class="fa-solid fa-check-circle"></i> Üye</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $row['telefon']; ?></td>
                                <td style="color:#c79c60; font-weight:600;"><?php echo $row['hizmet_turu'] ?? 'Genel'; ?></td>
                                <td>
                                    <?php echo date("d.m.Y", strtotime($row['randevu_tarihi'])); ?>
                                    <span style="color:#777; margin-left:5px;"><?php echo $row['randevu_saati']; ?></span>
                                </td>
                                <td>
                                    <a href="?sil_id=<?php echo $row['id']; ?>" class="action-btn" style="background:#dc3545;" onclick="return confirm('Silmek istediğine emin misin?')"><i class="fa-solid fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" style="text-align:center; padding:30px;">Kayıt yok.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</body>
</html>