<?php
/**
 * Dosya: admin/kullanicilar.php
 * Amaç: Müşteri listesini yönetir.
 * GÜVENLİK: PHP Session kontrolü eklenmiştir.
 */

// 1. OTURUM KONTROLÜ
session_start();

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    // Giriş yapılmamışsa ana sayfaya yönlendir
    header("Location: ../index.html?access=denied");
    exit;
}

include '../api/db.php';

// Kullanıcı Silme İşlemi
if(isset($_GET['sil_id'])) {
    $id = intval($_GET['sil_id']);
    // İlişkili randevuların bağını kopar (Silmek yerine anonim yapıyoruz)
    $conn->query("UPDATE randevular SET user_id = NULL WHERE user_id = $id");
    // Kullanıcıyı sil
    $conn->query("DELETE FROM users WHERE id=$id");
    header("Location: kullanicilar.php");
    exit;
}

// Tüm kullanıcıları çek
$sql = "SELECT * FROM users ORDER BY kayit_tarihi DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Müşteri Yönetimi</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@300;400;700&family=Playfair+Display:ital,wght@0,700;1,400&display=swap" rel="stylesheet">
    <!-- Ortak Admin CSS -->
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>

    <!-- SIDEBAR -->
    <aside class="sidebar">
        <div class="sidebar-header"><h2>BERBER</h2></div>
        <ul class="sidebar-menu">
            <li><a href="index.php"><i class="fa-solid fa-gauge"></i> <span>Panel</span></a></li>
            <li><a href="randevular.php"><i class="fa-solid fa-calendar-check"></i> <span>Randevular</span></a></li>
            <li><a href="kullanicilar.php" class="active"><i class="fa-solid fa-users"></i> <span>Kullanıcılar</span></a></li>
            <li><a href="bulten.php"><i class="fa-solid fa-envelope-open-text"></i> <span>E-Bülten</span></a></li>
            <li><a href="ayarlar.php"><i class="fa-solid fa-gear"></i> <span>Ayarlar</span></a></li>
            <li style="margin-top:auto; border-top:1px solid #333;">
                <a href="../index.html" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> <span>Siteye Git</span></a>
            </li>
        </ul>
    </aside>

    <!-- ANA İÇERİK -->
    <main class="main-content">
        <div class="admin-header">
            <div>
                <h1>Müşteri Listesi</h1>
                <p>Sisteme kayıt olan tüm müşterilerin detayları.</p>
            </div>
            <!-- GÜVENLİK: Çıkış Butonu -->
            <a href="logout.php" onclick="return confirm('Oturum kapatılsın mı?')" class="btn" style="background:#222; color:#fff; border:1px solid #444;">
                <i class="fa-solid fa-right-from-bracket"></i> Güvenli Çıkış
            </a>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ad Soyad</th>
                        <th>E-Posta</th>
                        <th>Telefon</th>
                        <th>Kayıt Tarihi</th>
                        <th>İşlem</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result && $result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td>#<?php echo $row['id']; ?></td>
                                <td style="font-weight:bold; color:#fff;">
                                    <?php 
                                        $ad = $row['ad'] ?? '';
                                        $soyad = $row['soyad'] ?? '';
                                        echo htmlspecialchars(trim($ad . ' ' . $soyad)) ?: 'İsimsiz Müşteri'; 
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <!-- Telefon numarasının çekildiği yer -->
                                <td style="color: var(--main-color); font-weight: 600;">
                                    <?php 
                                        echo (!empty($row['telefon'])) ? htmlspecialchars($row['telefon']) : '<span style="color:#555;">Girilmemiş</span>'; 
                                    ?>
                                </td>
                                <td><?php echo date("d.m.Y H:i", strtotime($row['kayit_tarihi'])); ?></td>
                                <td>
                                    <a href="?sil_id=<?php echo $row['id']; ?>" class="action-btn delete-btn" onclick="return confirm('Bu kullanıcıyı ve tüm verilerini silmek istediğinize emin misiniz?')">
                                        <i class="fa-solid fa-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" style="text-align:center; padding:50px; color:#666;">Henüz kayıtlı bir müşteri bulunamadı.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>

</body>
</html>