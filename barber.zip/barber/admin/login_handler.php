<?php
/**
 * Dosya: admin/login_handler.php
 * Amaç: Giriş bilgilerini DB üzerinden kontrol eder ve oturum başlatır.
 */
session_start();
include '../api/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $conn->real_escape_string($_POST['username'] ?? '');
    $password = $_POST['password'] ?? ''; // Veritabanındaki şifre şimdilik plain text olduğu için temizlemeye gerek yok, karşılaştıracağız.

    // Veritabanında bu kullanıcıyı ara
    $sql = "SELECT id, kullanici_adi, sifre FROM yoneticiler WHERE kullanici_adi = '$username' LIMIT 1";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Şifre kontrolü (Şu an DB'de plain text '123456' var)
        if ($password === $user['sifre']) {
            // ŞİFRE DOĞRU: Oturumu başlat
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_id'] = $user['id'];
            $_SESSION['admin_user'] = $user['kullanici_adi'];
            
            // Başarılı girişten sonra panele yönlendir
            header("Location: index.php");
            exit;
        } else {
            // ŞİFRE YANLIŞ
            header("Location: ../index.html?error=wrong_credentials");
            exit;
        }
    } else {
        // KULLANICI BULUNAMADI
        header("Location: ../index.html?error=user_not_found");
        exit;
    }
} else {
    // POST dışı erişim engeli
    header("Location: ../index.html");
    exit;
}

$conn->close();
?>