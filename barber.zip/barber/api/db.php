<?php
// XAMPP varsayılan ayarları
$host = "localhost";
$user = "root";
$pass = ""; // XAMPP'te şifre genellikle boştur
$db   = "berber_db";

// MySQLi bağlantısı oluşturma
$conn = new mysqli($host, $user, $pass, $db);

// Bağlantı kontrolü
if ($conn->connect_error) {
    // Gerçek projede hatayı ekrana basmak yerine loglamak daha güvenlidir
    die(json_encode(["status" => "error", "message" => "Veritabanı bağlantı hatası"]));
}

// Türkçe karakter sorunu olmaması için charset ayarı
$conn->set_charset("utf8");
?>