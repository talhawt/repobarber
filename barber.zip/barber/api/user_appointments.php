<?php
// Dosya: api/user_appointments.php
// Amaç: Giriş yapan kullanıcının randevularını getirir.

header('Content-Type: application/json');
include 'db.php';

// POST ile gelen veriyi al
$data = json_decode(file_get_contents("php://input"), true);

if(isset($data['uid'])) {
    $firebase_uid = $conn->real_escape_string($data['uid']);

    // 1. Önce Firebase UID'den bizim User ID'yi bulalım
    $userQuery = $conn->query("SELECT id FROM users WHERE firebase_uid = '$firebase_uid'");
    
    if($userQuery->num_rows > 0) {
        $userRow = $userQuery->fetch_assoc();
        $userId = $userRow['id'];

        // 2. Bu ID'ye ait randevuları çekelim
        $sql = "SELECT * FROM randevular WHERE user_id = $userId ORDER BY randevu_tarihi DESC, randevu_saati ASC";
        $result = $conn->query($sql);

        $randevular = [];
        while($row = $result->fetch_assoc()) {
            $randevular[] = $row;
        }

        echo json_encode(["status" => "success", "data" => $randevular]);
    } else {
        echo json_encode(["status" => "error", "message" => "Kullanıcı bulunamadı."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Yetkisiz erişim."]);
}

$conn->close();
?>