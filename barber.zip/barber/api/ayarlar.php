<?php
/**
 * Dosya: api/ayarlar.php
 * Amaç: Site ayarlarını veritabanından okur (GET) veya günceller (POST).
 * Manifesto ve Harita alanlarını tam destekler.
 */

header('Content-Type: application/json');
include 'db.php';

$method = $_SERVER['REQUEST_METHOD'];

// --- 1. VERİ OKUMA (GET İSTEĞİ) ---
// Sayfa yüklendiğinde renkleri ve metinleri getiren kısım burasıdır.
if ($method === 'GET') {
    $sql = "SELECT * FROM ayarlar WHERE id = 1";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode($row);
    } else {
        // Tablo boşsa JS'in çökmemesi için varsayılan değerler döndürür
        echo json_encode([
            'site_basligi' => 'Gold Makas',
            'ana_renk' => '#c79c60',
            'arka_plan' => '#1a1a1a',
            'status' => 'empty_db'
        ]);
    }
} 

// --- 2. VERİ GÜNCELLEME (POST İSTEĞİ) ---
// Admin panelinden "Kaydet" butonuna basıldığında çalışan kısım.
else if ($method === 'POST') {
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    if (!$data) {
        echo json_encode(['status' => 'error', 'message' => 'JSON verisi alınamadı.']);
        exit;
    }

    // Güvenlik: Verileri temizle
    $site_basligi    = $conn->real_escape_string($data['site_basligi'] ?? '');
    $hero_baslik     = $conn->real_escape_string($data['hero_baslik'] ?? '');
    $hero_alt        = $conn->real_escape_string($data['hero_alt'] ?? '');
    $manifesto_baslik = $conn->real_escape_string($data['manifesto_baslik'] ?? '');
    $manifesto_metin  = $conn->real_escape_string($data['manifesto_metin'] ?? '');
    $manifesto_resim  = $conn->real_escape_string($data['manifesto_resim'] ?? '');
    $adres           = $conn->real_escape_string($data['adres'] ?? '');
    $adres_ilce      = $conn->real_escape_string($data['adres_ilce'] ?? '');
    $telefon         = $conn->real_escape_string($data['telefon'] ?? '');
    $email_iletisim  = $conn->real_escape_string($data['email_iletisim'] ?? '');
    $instagram       = $conn->real_escape_string($data['instagram'] ?? '');
    $facebook_url    = $conn->real_escape_string($data['facebook_url'] ?? '');
    $youtube_url     = $conn->real_escape_string($data['youtube_url'] ?? '');
    $calisma_saatleri = $conn->real_escape_string($data['calisma_saatleri'] ?? '');
    $harita_iframe   = $conn->real_escape_string($data['harita_iframe'] ?? '');
    $ana_renk        = $conn->real_escape_string($data['ana_renk'] ?? '#c79c60');
    $arka_plan       = $conn->real_escape_string($data['arka_plan'] ?? '#121212');

    $sql = "UPDATE ayarlar SET 
            site_basligi = '$site_basligi',
            hero_baslik = '$hero_baslik',
            hero_alt = '$hero_alt',
            manifesto_baslik = '$manifesto_baslik',
            manifesto_metin = '$manifesto_metin',
            manifesto_resim = '$manifesto_resim',
            adres = '$adres',
            adres_ilce = '$adres_ilce',
            telefon = '$telefon',
            email_iletisim = '$email_iletisim',
            instagram = '$instagram',
            facebook_url = '$facebook_url',
            youtube_url = '$youtube_url',
            calisma_saatleri = '$calisma_saatleri',
            harita_iframe = '$harita_iframe',
            ana_renk = '$ana_renk',
            arka_plan = '$arka_plan'
            WHERE id = 1";

    if ($conn->query($sql)) {
        echo json_encode(['status' => 'success', 'message' => 'Ayarlar başarıyla güncellendi.']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Hata: ' . $conn->error]);
    }
}

$conn->close();
?>