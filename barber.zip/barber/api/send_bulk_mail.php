<?php
/**
 * Dosya: api/send_bulk_mail.php
 * Amaç: Manuel PHPMailer kurulumu ile bülten abonelerine toplu mail gönderimi.
 */

header('Content-Type: application/json');
include 'db.php';

// Manuel PHPMailer Yüklemesi
require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Gelen JSON verisini oku
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!$data || empty($data['subject']) || empty($data['message'])) {
    echo json_encode(['status' => 'error', 'message' => 'Konu veya mesaj içeriği boş bırakılamaz.']);
    exit;
}

$subject = $data['subject'];
$message = $data['message'];

// 1. Aboneleri Çek
$sql = "SELECT email FROM bulten";
$result = $conn->query($sql);

if (!$result || $result->num_rows === 0) {
    echo json_encode(['status' => 'error', 'message' => 'Bültende kayıtlı abone bulunamadı.']);
    exit;
}

// 2. PHPMailer Yapılandırması
$mail = new PHPMailer(true);

try {
    // --- SMTP KONFİGÜRASYONU ---
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com'; 
    $mail->SMTPAuth   = true;
    
    // BURAYI KENDİ BİLGİLERİNLE DOLDURMALISIN
    $mail->Username   = 'goldmakasdestek@gmail.com'; 
    $mail->Password   = 'snvi vsmd pxdx ucpc'; // Google Uygulama Şifresi
    
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;
    $mail->CharSet    = 'UTF-8';
    
    // Gönderen Bilgisi
    $mail->setFrom('goldmakasdestek@gmail.com', 'Gold Makas');
    $mail->isHTML(true);
    $mail->Subject = $subject;

    $successCount = 0;
    $failCount = 0;

    // 3. Gönderim Döngüsü
    while ($row = $result->fetch_assoc()) {
        try {
            $mail->clearAddresses();
            $mail->addAddress($row['email']);
            
            // Mail Şablonu
            $mail->Body = "
                <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #eee; border-radius: 8px; overflow: hidden;'>
                    <div style='background: #121212; padding: 25px; text-align: center;'>
                        <h1 style='color: #c79c60; margin: 0; letter-spacing: 2px;'>GOLD MAKAS</h1>
                    </div>
                    <div style='padding: 30px; color: #333;'>
                        <h2 style='color: #121212;'>Değerli Abonemiz,</h2>
                        <div style='line-height: 1.6; font-size: 16px;'>{$message}</div>
                        <br><br>
                        <p style='font-size: 14px; color: #777;'>Keyifli günler dileriz.</p>
                    </div>
                    <div style='background: #f8f8f8; padding: 15px; text-align: center; font-size: 11px; color: #999;'>
                        Bu ileti bülten aboneliğiniz kapsamında gönderilmiştir.
                    </div>
                </div>";

            if ($mail->send()) {
                $successCount++;
            }
        } catch (Exception $e) {
            $failCount++;
        }
    }

    echo json_encode([
        'status' => 'success', 
        'message' => "Gönderim tamamlandı. Toplam: {$successCount} başarılı, {$failCount} hatalı."
    ]);

} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => "Bağlantı kurulamadı: {$mail->ErrorInfo}"]);
}

$conn->close();
?>