<?php
// Dosya: api/cancel_appointment.php
// Amaç: Kullanıcının kendi randevusunu iptal etmesini sağlar.

header('Content-Type: application/json');
include 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

if(isset($data['id']) && isset($data['uid'])) {
    $randevu_id = intval($data['id']);
    $firebase_uid = $conn->real_escape_string($data['uid']);

    // 1. Önce bu Firebase UID'ye sahip kullanıcının ID'sini bulalım
    $userQuery = $conn->query("SELECT id FROM users WHERE firebase_uid = '$firebase_uid'");
    
    if($userQuery->num_rows > 0) {
        $userRow = $userQuery->fetch_assoc();
        $user_id = $userRow['id'];

        // 2. Randevunun bu kullanıcıya ait olup olmadığını kontrol et ve SİL
        // user_id kontrolü güvenlik içindir.
        $deleteSql = "DELETE FROM randevular WHERE id = $randevu_id AND user_id = $user_id";
        
        if($conn->query($deleteSql) === TRUE) {
            if($conn->affected_rows > 0) {
                echo json_encode(["status" => "success", "message" => "Randevu başarıyla iptal edildi."]);
            } else {
                echo json_encode(["status" => "error", "message" => "Randevu bulunamadı veya size ait değil."]);
            }
        } else {
            echo json_encode(["status" => "error", "message" => "Veritabanı hatası: " . $conn->error]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Kullanıcı doğrulanamadı."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Eksik veri."]);
}

$conn->close();
?>