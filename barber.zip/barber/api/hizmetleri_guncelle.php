<?php
// Dosya: api/hizmetleri_guncelle.php
// Amaç: Admin panelinden gelen tüm hizmet kartlarını topluca güncellemek.

header('Content-Type: application/json');
include 'db.php';

// JSON verisini al
$data = json_decode(file_get_contents('php://input'), true);

if (!$data || !isset($data['hizmetler'])) {
    echo json_encode(['status' => 'error', 'message' => 'Geçersiz veri formatı.']);
    exit;
}

$hizmetler = $data['hizmetler'];

// Transaction başlat (Hata olursa geri almak için)
$conn->begin_transaction();

try {
    // 1. Mevcut tüm hizmetleri temizle (Basit ve etkili yöntem)
    // Not: Eğer id'leri korumak isterseniz daha karmaşık bir UPDATE/DELETE mantığı gerekir.
    // Ancak bu tip "liste yönetimi" sayfalarında temizleyip yeniden eklemek daha hızlıdır.
    $conn->query("TRUNCATE TABLE hizmetler");

    // 2. Yeni listedeki her hizmeti tek tek ekle
    $stmt = $conn->prepare("INSERT INTO hizmetler (baslik, aciklama, fiyat, ikon, ozellikler, sira) VALUES (?, ?, ?, ?, ?, ?)");

    foreach ($hizmetler as $h) {
        $baslik = $h['baslik'];
        $aciklama = $h['aciklama'];
        $fiyat = $h['fiyat'];
        $ikon = $h['ikon'];
        $ozellikler = $h['ozellikler'];
        $sira = intval($h['sira']);

        $stmt->bind_param("sssssi", $baslik, $aciklama, $fiyat, $ikon, $ozellikler, $sira);
        $stmt->execute();
    }

    $conn->commit();
    echo json_encode(['status' => 'success', 'message' => 'Hizmetler başarıyla güncellendi.']);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['status' => 'error', 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
}

$conn->close();
?>