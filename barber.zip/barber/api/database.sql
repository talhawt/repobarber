-- phpMyAdmin SQL Dump
-- Sürüm: 1.1
-- Veritabanı: `berber_db`

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+03:00";

-- --------------------------------------------------------

--
-- 1. Tablo yapısı: `ayarlar`
-- Site genel ayarları, renkler, iletişim, manifesto ve harita bilgileri.
--

CREATE TABLE IF NOT EXISTS `ayarlar` (
  `id` int(11) NOT NULL,
  `site_basligi` varchar(255) DEFAULT 'Berber Randevu Sistemi',
  `hero_baslik` varchar(255) DEFAULT 'Tarzını Bizimle Keşfet',
  `hero_alt` varchar(255) DEFAULT 'Profesyonel dokunuşlar, modern kesimler.',
  `manifesto_baslik` varchar(255) DEFAULT 'Vizyonumuz & Tutkumuz',
  `manifesto_metin` text DEFAULT NULL,
  `manifesto_resim` text DEFAULT NULL,
  `adres` varchar(255) DEFAULT 'Bağdat Cad. No:1, İstanbul',
  `adres_ilce` varchar(100) DEFAULT 'Kadıköy / İstanbul',
  `telefon` varchar(20) DEFAULT '+90 (212) 123 45 67',
  `email_iletisim` varchar(100) DEFAULT 'goldmakasdestek@gmail.com',
  `instagram` varchar(100) DEFAULT '@berberim',
  `facebook_url` varchar(255) DEFAULT '#',
  `youtube_url` varchar(255) DEFAULT '#',
  `calisma_saatleri` text DEFAULT 'Pzt-Cum: 09:00 - 21:00\nCmt: 10:00 - 20:00\nPaz: Kapalı',
  `harita_iframe` text DEFAULT NULL,
  `ana_renk` varchar(20) DEFAULT '#c79c60',
  `arka_plan` varchar(20) DEFAULT '#1a1a1a',
  `logo_url` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- Varsayılan Ayarlar
INSERT INTO `ayarlar` (`id`, `site_basligi`, `hero_baslik`, `hero_alt`, `manifesto_baslik`, `manifesto_metin`, `manifesto_resim`, `adres`, `adres_ilce`, `telefon`, `email_iletisim`, `instagram`, `facebook_url`, `youtube_url`, `calisma_saatleri`, `harita_iframe`, `ana_renk`, `arka_plan`) 
VALUES (1, 'Gold Makas', 'Tarzını Baştan Yarat', 'Şehrin en iyi kesimi ve bakımı.', 'Zanaat ve Estetik', 'Gold Makas olarak, sadece saç kesmiyoruz; karakterinizi yansıtan bir sanat icra ediyoruz. 20 yılı aşkın tecrübemizle modern ve klasik dokunuşları bir araya getiriyoruz.', 'https://images.unsplash.com/photo-1503951914875-befbb713346b?auto=format&fit=crop&w=800&q=80', 'Bağdat Cad. No:1', 'Kadıköy / İstanbul', '+90 (212) 123 45 67', 'goldmakasdestek@gmail.com', '@goldmakas', '#', '#', 'Pazartesi: Kapalı\nSalı - Cuma: 09:00 - 21:30\nCumartesi: 09:00 - 21:30\nPazar: 10:00 - 20:00', '', '#c79c60', '#1a1a1a')
ON DUPLICATE KEY UPDATE id=1;

-- --------------------------------------------------------

--
-- 2. Tablo yapısı: `users`
-- Müşteri hesapları.
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firebase_uid` varchar(128) NOT NULL,
  `email` varchar(255) NOT NULL,
  `ad` varchar(50) DEFAULT NULL,
  `soyad` varchar(50) DEFAULT NULL,
  `telefon` varchar(20) DEFAULT NULL,
  `kayit_tarihi` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `firebase_uid` (`firebase_uid`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- 3. Tablo yapısı: `randevular`
-- Randevular.
--

CREATE TABLE IF NOT EXISTS `randevular` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `ad_soyad` varchar(100) NOT NULL,
  `telefon` varchar(20) NOT NULL,
  `hizmet_turu` varchar(100) NOT NULL DEFAULT 'Saç Kesimi',
  `randevu_tarihi` date NOT NULL,
  `randevu_saati` varchar(10) NOT NULL,
  `olusturulma_tarihi` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- 4. Tablo yapısı: `bulten`
-- E-Bülten abonelikleri.
--

CREATE TABLE IF NOT EXISTS `bulten` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `kayit_tarihi` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- --------------------------------------------------------

--
-- 5. Tablo yapısı: `hizmetler`
-- Ana sayfadaki hizmet kartlarını yönetmek için.
--

CREATE TABLE IF NOT EXISTS `hizmetler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `baslik` varchar(100) NOT NULL,
  `aciklama` varchar(255) NOT NULL,
  `fiyat` varchar(50) NOT NULL,
  `ikon` varchar(50) DEFAULT 'fa-solid fa-scissors',
  `ozellikler` text DEFAULT NULL,
  `sira` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- Varsayılan Hizmetler (GÜNCELLENDİ: TÜM SEÇENEKLER EKLENDİ)
-- Not: Bu verileri içeri aktarmadan önce 'hizmetler' tablosunu boşaltmanız (TRUNCATE) önerilir.
INSERT INTO `hizmetler` (`id`, `baslik`, `aciklama`, `fiyat`, `ikon`, `ozellikler`, `sira`) VALUES
(1, 'Saç Kesimi', 'Yüz tipinize en uygun modern ve klasik kesimler.', '250 TL', 'fa-solid fa-scissors', 'Yüz tipine uygun analiz,Modern & Klasik kesimler,Yıkama ve Fön,Şekillendirme', 1),
(2, 'Sakal Tasarımı', 'Jilet veya makine ile profesyonel sakal şekillendirme.', '150 TL', 'fa-solid fa-user-tie', 'Sıcak havlu kompresi,Ustura veya makine ile traş,Cilt tahriş önleyici bakım,Sakal serumu uygulaması', 2),
(3, 'Saç + Sakal', 'Tam paket bakım ile yenilenin.', '350 TL', 'fa-solid fa-users', 'Saç Kesimi,Sakal Tıraşı,Yıkama ve Fön,Özel Bakım', 3),
(4, 'Cilt Bakımı', 'Buhar maskesi ve özel kremlerle ferah bir cilt.', '400 TL', 'fa-solid fa-spa', 'Buhar banyosu ile gözenek açma,Siyah nokta temizliği,Kil maskesi,Nemlendirici masaj', 4),
(5, 'Full Bakım', 'Kral paketi: Saç, Sakal ve Cilt Bakımı bir arada.', '700 TL', 'fa-solid fa-crown', 'Saç ve Sakal Kesimi,Detaylı Cilt Bakımı,Yüz Maskesi,Masaj', 5),
(6, 'Çocuk Tıraşı', 'Küçük beyler için özenli ve eğlenceli kesim.', '200 TL', 'fa-solid fa-child', 'Hassas kesim,Çizgi film eşliğinde,Şeker ikramı,Hatıra fotoğrafı', 6),
(7, 'Saç Boyama', 'Beyaz kapatma veya yeni tarz renkler.', '500 TL', 'fa-solid fa-palette', 'Kaliteli boya,Doğal görünüm,Renk danışmanlığı,Koruyucu bakım', 7),
(8, 'Fön / Şekillendirme', 'Özel günleriniz için hızlı şekillendirme.', '100 TL', 'fa-solid fa-wind', 'Yıkama,Fön,Sprey ile sabitleme,Gün boyu kalıcılık', 8)
ON DUPLICATE KEY UPDATE baslik=VALUES(baslik), fiyat=VALUES(fiyat), ozellikler=VALUES(ozellikler);

-- --------------------------------------------------------

--
-- 6. Tablo yapısı: `yoneticiler`
-- Admin paneli girişi.
--

CREATE TABLE IF NOT EXISTS `yoneticiler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kullanici_adi` varchar(50) NOT NULL,
  `sifre` varchar(255) NOT NULL,
  `rol` varchar(20) NOT NULL DEFAULT 'admin',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

INSERT INTO `yoneticiler` (`id`, `kullanici_adi`, `sifre`, `rol`) VALUES
(1, 'admin', '123456', 'admin')
ON DUPLICATE KEY UPDATE id=1;

COMMIT;