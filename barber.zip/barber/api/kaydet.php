<?php
header('Content-Type: application/json');
include 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

if(isset($data['telefon'], $data['ad_soyad'], $data['tarih'], $data['saat'])) {
    
    $ad = $conn->real_escape_string($data['ad_soyad']);
    $tel = $conn->real_escape_string($data['telefon']);
    $tarih = $conn->real_escape_string($data['tarih']);
    $saat = $conn->real_escape_string($data['saat']);
    // YENİ: Hizmet Türünü Al (Eğer gelmezse varsayılan 'Saç Kesimi' olsun)
    $hizmet = isset($data['hizmet_turu']) ? $conn->real_escape_string($data['hizmet_turu']) : 'Saç Kesimi';
    
    // User ID kontrolü
    $user_id = 'NULL';
    if(isset($data['user_uid']) && !empty($data['user_uid'])) {
        $uid = $conn->real_escape_string($data['user_uid']);
        $u_query = $conn->query("SELECT id FROM users WHERE firebase_uid = '$uid'");
        if($u_query->num_rows > 0) {
            $u_row = $u_query->fetch_assoc();
            $user_id = $u_row['id'];
        }
    }

    $kontrol = $conn->query("SELECT id FROM randevular WHERE randevu_tarihi='$tarih' AND randevu_saati='$saat'");
    
    if($kontrol->num_rows > 0){
        echo json_encode(["status" => "error", "message" => "Seçilen tarih ve saat dolu."]);
    } else {
        // GÜNCELLEME: hizmet_turu sütununa veriyi yazıyoruz
        $sql = "INSERT INTO randevular (user_id, ad_soyad, telefon, randevu_tarihi, randevu_saati, hizmet_turu) VALUES ($user_id, '$ad', '$tel', '$tarih', '$saat', '$hizmet')";
        
        if ($conn->query($sql) === TRUE) {
            echo json_encode(["status" => "success", "message" => "Randevu oluşturuldu."]);
        } else {
            echo json_encode(["status" => "error", "message" => "SQL Hatası: " . $conn->error]);
        }
    }
} else {
    echo json_encode(["status" => "error", "message" => "Eksik veri."]);
}
$conn->close();
?>