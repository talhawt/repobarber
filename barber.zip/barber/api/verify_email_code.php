<?php
// Dosya: api/verify_email_code.php
session_start();
header('Content-Type: application/json');
error_reporting(0); 
ini_set('display_errors', 0);

$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['code'])) {
    $userCode = $data['code'];
    
    if (!isset($_SESSION['otp_code'])) {
        echo json_encode(["status" => "error", "message" => "Kodun süresi dolmuş veya oturum kapanmış."]);
        exit;
    }

    if ($_SESSION['otp_code'] == $userCode) {
        unset($_SESSION['otp_code']); // Kodu tek kullanımlık yap
        echo json_encode(["status" => "success", "message" => "Doğrulama başarılı!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Hatalı kod girdiniz."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Kod boş gönderildi."]);
}
?>