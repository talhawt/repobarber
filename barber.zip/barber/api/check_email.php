<?php
// Dosya: api/check_email.php
// Amaç: E-posta adresinin veritabanında kayıtlı olup olmadığını kontrol eder.

header('Content-Type: application/json');
include 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

if (isset($data['email'])) {
    $email = $conn->real_escape_string($data['email']);
    
    // E-posta veritabanında var mı?
    $check = $conn->query("SELECT id FROM users WHERE email = '$email'");
    
    if ($check->num_rows > 0) {
        echo json_encode(["status" => "exists", "message" => "E-posta bulundu."]);
    } else {
        echo json_encode(["status" => "not_found", "message" => "Bu e-posta adresiyle kayıtlı bir kullanıcı bulunamadı."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "E-posta adresi eksik."]);
}

$conn->close();
?>