<?php
// Dosya: api/login_sync.php
// Amaç: Firebase'den gelen kullanıcı verilerini (Ad, Soyad, Email, Telefon) MySQL ile senkronize eder.

header('Content-Type: application/json');
include 'db.php';

// Gelen JSON verisini oku
$json = file_get_contents('php://input');
$data = json_decode($json, true);

if (!$data || !isset($data['uid'])) {
    echo json_encode(['status' => 'error', 'message' => 'UID bilgisi eksik.']);
    exit;
}

// Verileri temizle (SQL Injection önlemi)
$uid = $conn->real_escape_string($data['uid']);
$email = $conn->real_escape_string($data['email'] ?? '');
$ad = $conn->real_escape_string($data['ad'] ?? '');
$soyad = $conn->real_escape_string($data['soyad'] ?? '');
$telefon = $conn->real_escape_string($data['telefon'] ?? '');

// Kullanıcı veritabanında var mı kontrol et
$checkQuery = "SELECT id FROM users WHERE firebase_uid = '$uid'";
$result = $conn->query($checkQuery);

if ($result && $result->num_rows > 0) {
    // MEVCUT KULLANICIYI GÜNCELLE
    // Telefon numarası boş gelmemişse güncellemeye dahil et
    $updateFields = "email = '$email', ad = '$ad', soyad = '$soyad'";
    if (!empty($telefon)) {
        $updateFields .= ", telefon = '$telefon'";
    }
    
    $sql = "UPDATE users SET $updateFields WHERE firebase_uid = '$uid'";
} else {
    // YENİ KULLANICI EKLE
    $sql = "INSERT INTO users (firebase_uid, email, ad, soyad, telefon) 
            VALUES ('$uid', '$email', '$ad', '$soyad', '$telefon')";
}

if ($conn->query($sql)) {
    echo json_encode([
        'status' => 'success', 
        'message' => 'Kullanıcı verileri başarıyla senkronize edildi.',
        'data' => [
            'uid' => $uid,
            'telefon' => $telefon
        ]
    ]);
} else {
    echo json_encode([
        'status' => 'error', 
        'message' => 'Veritabanı senkronizasyon hatası: ' . $conn->error
    ]);
}

$conn->close();
?>