<?php
// api/dolu_saatler.php - Seçilen tarihteki dolu randevuları JSON olarak döndürür
header('Content-Type: application/json');
include 'db.php';

// Tarih parametresini al (Örn: ?tarih=2024-10-25)
$tarih = isset($_GET['tarih']) ? $conn->real_escape_string($_GET['tarih']) : date('Y-m-d');

// O tarihteki tüm randevu saatlerini çek
$sql = "SELECT randevu_saati FROM randevular WHERE randevu_tarihi = '$tarih'";
$result = $conn->query($sql);

$dolu_saatler = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $dolu_saatler[] = $row['randevu_saati'];
    }
}

// JSON olarak döndür
echo json_encode($dolu_saatler);

$conn->close();
?>