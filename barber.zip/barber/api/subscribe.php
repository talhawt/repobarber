<?php
header('Content-Type: application/json');
include 'db.php';

$data = json_decode(file_get_contents("php://input"), true);

if(isset($data['email'])) {
    $email = $conn->real_escape_string($data['email']);

    // E-posta formatı kontrolü
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(["status" => "error", "message" => "Geçersiz e-posta formatı."]);
        exit;
    }

    // Zaten kayıtlı mı?
    $check = $conn->query("SELECT id FROM bulten WHERE email='$email'");
    if($check->num_rows > 0) {
        echo json_encode(["status" => "error", "message" => "Bu e-posta zaten bülten listesinde kayıtlı."]);
    } else {
        $sql = "INSERT INTO bulten (email) VALUES ('$email')";
        if($conn->query($sql)) {
            echo json_encode(["status" => "success", "message" => "Bültene başarıyla abone oldunuz!"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Veritabanı hatası."]);
        }
    }
} else {
    echo json_encode(["status" => "error", "message" => "E-posta girilmedi."]);
}
$conn->close();
?>