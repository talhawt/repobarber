<?php
// Dosya: api/send_email_code.php
// Amaç: Gmail SMTP kullanarak gerçek e-posta gönderir.

session_start();
header('Content-Type: application/json');

// Hataları ekrana basma, JSON yapısını bozar.
error_reporting(0);
ini_set('display_errors', 0);

// PHPMailer Dosyalarını Dahil Et
// (api/PHPMailer klasörünün orada olduğundan emin ol)
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/Exception.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';

try {
    $input = file_get_contents("php://input");
    $data = json_decode($input, true);

    if (isset($data['email'])) {
        $userEmail = $data['email'];
        
        // 6 Haneli Rastgele Kod
        $verificationCode = rand(100000, 999999);
        
        // Session'a kaydet
        $_SESSION['otp_code'] = $verificationCode;
        $_SESSION['otp_email'] = $userEmail;
        $_SESSION['otp_time'] = time();

        // --- PHPMailer Ayarları ---
        $mail = new PHPMailer(true);

        // Sunucu Ayarları
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'goldmakasdestek@gmail.com'; // Senin Gmail Adresin
        $mail->Password   = 'snvi vsmd pxdx ucpc'; // Google'dan aldığın Uygulama Şifresi
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->CharSet    = 'UTF-8';

        // Alıcı Ayarları
        $mail->setFrom('goldmakasdestek@gmail.com', 'Gold Makas');
        $mail->addAddress($userEmail); // Kullanıcının girdiği mail

        // İçerik
        $mail->isHTML(true);
        $mail->Subject = 'Doğrulama Kodunuz - Berber Randevu';
        $mail->Body    = "
            <div style='font-family: Arial, sans-serif; padding: 20px; background-color: #f4f4f4;'>
                <div style='background-color: #fff; padding: 20px; border-radius: 5px; text-align: center;'>
                    <h2 style='color: #c79c60;'>Gold Makas</h2>
                    <p>Randevu kayıt işleminizi tamamlamak için doğrulama kodunuz:</p>
                    <h1 style='font-size: 32px; letter-spacing: 5px; color: #333;'>$verificationCode</h1>
                    <p style='color: #999; font-size: 12px;'>Bu kodu kimseyle paylaşmayınız.</p>
                </div>
            </div>
        ";
        $mail->AltBody = "Doğrulama Kodunuz: " . $verificationCode;

        $mail->send();

        echo json_encode([
            "status" => "success", 
            "message" => "Doğrulama kodu e-posta adresinize gönderildi."
        ]);
        
    } else {
        echo json_encode(["status" => "error", "message" => "E-posta adresi alınamadı."]);
    }
} catch (Exception $e) {
    // Hata durumunda detaylı bilgi (Geliştirme aşamasında $mail->ErrorInfo kullanılabilir)
    // Canlıda kullanıcıya genel hata dönülür.
    echo json_encode([
        "status" => "error", 
        "message" => "Mail gönderilemedi. Lütfen mail adresinizi kontrol edin. (Hata: Mail Sunucusu)"
    ]);
}
?>