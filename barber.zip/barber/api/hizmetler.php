<?php
// Dosya: api/hizmetler.php
header('Content-Type: application/json');
include 'db.php';

$sql = "SELECT * FROM hizmetler ORDER BY sira ASC";
$result = $conn->query($sql);

$hizmetler = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $hizmetler[] = $row;
    }
}

echo json_encode($hizmetler);
$conn->close();
?>