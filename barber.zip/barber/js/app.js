import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js";
import { getAuth, RecaptchaVerifier, signInWithPhoneNumber, signInWithPopup, GoogleAuthProvider, createUserWithEmailAndPassword, signInWithEmailAndPassword, updateProfile, updateEmail, updatePassword, signOut, onAuthStateChanged, EmailAuthProvider, linkWithCredential, PhoneAuthProvider } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";

// --- FIREBASE KONFİGÜRASYONU ---
const firebaseConfig = {
  apiKey: "AIzaSyAJOq9Y8C1S5AWP79oLbUbWc25IDKHzAcg",
  authDomain: "barber-86433.firebaseapp.com",
  projectId: "barber-86433",
  storageBucket: "barber-86433.firebasestorage.app",
  messagingSenderId: "1032802718004",
  appId: "1:1032802718004:web:d2204ed66d9544adf45561",
  measurementId: "G-0925B75DDT"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
auth.languageCode = 'tr';
const googleProvider = new GoogleAuthProvider();

let currentUserUID = null;

// --- YARDIMCI: GÜVENLİ METİN/ELEMENT ATAMA ---
function setTextIfExists(elementId, text) {
    const element = document.getElementById(elementId);
    if (element) element.innerText = text;
}

function setHtmlIfExists(elementId, html) {
    const element = document.getElementById(elementId);
    if (element) element.innerHTML = html;
}

// --- YARDIMCI: İSİM DOĞRULAMA (REGEX) ---
function validateName(text) {
    // Sadece harf ve boşluklara izin ver
    const regex = /^[a-zA-ZçÇğĞıİöÖşŞüÜ\s]+$/;
    return regex.test(text);
}

// --- 1. AUTH DURUMUNU DİNLEME ---
onAuthStateChanged(auth, (user) => {
    if (user) {
        // Kullanıcı giriş yaptı
        currentUserUID = user.uid;
        updateUIForLogin(user);
        
        // Google girişleri için sync (Sessiz modda)
        if(user.displayName) {
            syncUserToDBFromObject(user);
        }
        
        // Eğer Randevularım sayfasındaysak verileri çek
        if (window.location.href.indexOf('randevularim.html') > -1) {
            loadUserAppointments(user.uid);
        }
        
        // Modal otomatik doldurma (Sadece elementler varsa)
        const rAd = document.getElementById('randevu_ad');
        const rSoyad = document.getElementById('randevu_soyad');
        const rEmail = document.getElementById('randevu_email');
        const rTel = document.getElementById('telefon');
        
        if(rAd && rSoyad && user.displayName) {
            const parts = user.displayName.split(' ');
            if (parts.length > 1) {
                rSoyad.value = parts.pop();
                rAd.value = parts.join(' ');
            } else {
                rAd.value = parts[0];
            }
        }
        if(rEmail && user.email) rEmail.value = user.email;
        if(rTel && user.phoneNumber) {
             let cleanPhone = user.phoneNumber.replace('+90', '');
             rTel.value = cleanPhone;
        }
        
    } else {
        // Kullanıcı çıkış yaptı
        currentUserUID = null;
        updateUIForLogout();
        
        // Eğer randevularım sayfasındaysa ana sayfaya at (Güvenlik)
        if (window.location.href.indexOf('randevularim.html') > -1) {
            window.location.href = 'index.html';
        }
    }
});

// --- 2. UI GÜNCELLEME ---
function updateUIForLogin(user) {
    let gosterilecekIsim = "Kullanıcı";
    if (user.displayName) gosterilecekIsim = user.displayName.split(' ')[0];

    const guestNav = document.getElementById('guest-nav');
    const userNav = document.getElementById('user-nav');
    if(guestNav) guestNav.style.display = 'none';
    if(userNav) {
        userNav.style.display = 'flex';
        setTextIfExists('user-name-display', "Merhaba, " + gosterilecekIsim);
    }

    const mGuest = document.getElementById('mobile-guest-nav');
    const mUser = document.getElementById('mobile-user-nav');
    if(mGuest) mGuest.style.display = 'none';
    if(mUser) {
        mUser.style.display = 'block';
        setTextIfExists('mobile-user-name', gosterilecekIsim);
    }
    
    // --- FOOTER DİNAMİK GÜNCELLEMELERİ ---
    const fRandevu = document.getElementById('footerRandevularimLink');
    if(fRandevu) fRandevu.style.display = 'block';

    const fLogin = document.getElementById('footerLoginLi');
    const fRegister = document.getElementById('footerRegisterLi');
    const fLogout = document.getElementById('footerLogoutLi');
    
    if(fLogin) fLogin.style.display = 'none';
    if(fRegister) fRegister.style.display = 'none';
    if(fLogout) fLogout.style.display = 'block';
    
    // Modal Yönetimi - Giriş yapmışsa email/şifre sorma
    const divEmail = document.getElementById('div_randevu_email');
    const divPass = document.getElementById('div_randevu_sifre');
    const btnKodGonder = document.getElementById('btn_kod_gonder'); 
    const btnDirect = document.getElementById('btn_randevu_kaydet_direct');
    const dogrulamaAlani = document.getElementById('dogrulamaAlani');
    
    if(divEmail) divEmail.style.display = 'none';
    if(divPass) divPass.style.display = 'none';
    if(btnKodGonder) btnKodGonder.style.display = 'none';
    if(btnDirect) btnDirect.style.display = 'block';
    if(dogrulamaAlani) dogrulamaAlani.style.display = 'none';

    const loginModal = document.getElementById('loginModal');
    const registerModal = document.getElementById('registerModal');
    if(loginModal) loginModal.style.display = 'none';
    if(registerModal) registerModal.style.display = 'none';
}

function updateUIForLogout() {
    const guestNav = document.getElementById('guest-nav');
    const userNav = document.getElementById('user-nav');
    if(guestNav) guestNav.style.display = 'flex';
    if(userNav) userNav.style.display = 'none';

    const mGuest = document.getElementById('mobile-guest-nav');
    const mUser = document.getElementById('mobile-user-nav');
    if(mGuest) mGuest.style.display = 'block';
    if(mUser) mUser.style.display = 'none';

    // --- FOOTER DİNAMİK SIFIRLAMA ---
    const fRandevu = document.getElementById('footerRandevularimLink');
    if(fRandevu) fRandevu.style.display = 'none';

    const fLogin = document.getElementById('footerLoginLi');
    const fRegister = document.getElementById('footerRegisterLi');
    const fLogout = document.getElementById('footerLogoutLi');
    
    if(fLogin) fLogin.style.display = 'block';
    if(fRegister) fRegister.style.display = 'block';
    if(fLogout) fLogout.style.display = 'none';

    // Modal Reset
    const divEmail = document.getElementById('div_randevu_email');
    const divPass = document.getElementById('div_randevu_sifre');
    const btnKodGonder = document.getElementById('btn_kod_gonder');
    const btnDirect = document.getElementById('btn_randevu_kaydet_direct');
    
    if(divEmail) divEmail.style.display = 'block';
    if(divPass) divPass.style.display = 'block';
    if(btnKodGonder) btnKodGonder.style.display = 'block';
    if(btnDirect) btnDirect.style.display = 'none';
}

// --- 3. GİRİŞ & KAYIT ---
window.googleLogin = function() {
    signInWithPopup(auth, googleProvider)
    .then(() => {
        location.reload();
    })
    .catch((error) => { alert("Google Hata: " + error.message); });
}

// Kayıt İçin Kod Gönder (Register Modal)
window.sendRegisterCode = function() {
    const email = document.getElementById('regEmail').value;
    const ad = document.getElementById('regName').value;
    const soyad = document.getElementById('regSurname').value;
    const pass = document.getElementById('regPassword').value;

    if(!email || !ad || !soyad || !pass) { 
        alert("Lütfen tüm alanları doldurun."); return; 
    }

    if (!validateName(ad) || !validateName(soyad)) {
        alert("Ad ve Soyad alanlarında sadece harf kullanılabilir."); return;
    }

    if(pass.length < 6) {
        alert("Şifre en az 6 karakter olmalı."); return;
    }

    fetch('api/send_email_code.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email })
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === 'success') {
            alert(data.message); 
            if(data.debug_code) alert("TEST KODU: " + data.debug_code); 
            
            document.getElementById('registerStep1').style.display = 'none';
            document.getElementById('registerStep2').style.display = 'block';
        } else {
            alert("Hata: " + data.message);
        }
    })
    .catch(err => alert("Mail sunucu hatası."));
}

// Kaydı Tamamla (Register Modal)
window.completeRegister = function() {
    const code = document.getElementById('regVerifyCode').value;
    if(!code) { alert("Kodu girin."); return; }

    fetch('api/verify_email_code.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: code })
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === 'success') {
            const email = document.getElementById('regEmail').value;
            const pass = document.getElementById('regPassword').value;
            const ad = document.getElementById('regName').value;
            const soyad = document.getElementById('regSurname').value;

            createUserWithEmailAndPassword(auth, email, pass)
            .then((userCredential) => {
                const user = userCredential.user;
                return updateProfile(user, { displayName: ad + " " + soyad })
                .then(() => {
                    return syncUserToDB({ uid: user.uid, email: user.email, ad: ad, soyad: soyad });
                });
            })
            .then(() => {
                alert("Kayıt Başarılı! Hoş geldiniz.");
                location.reload();
            })
            .catch((error) => {
                alert("Kayıt Hatası: " + error.message);
            });
        } else {
            alert("Hata: " + data.message);
        }
    })
    .catch(err => alert("Doğrulama hatası."));
}

window.emailLogin = function() {
    const email = document.getElementById('loginEmail').value;
    const pass = document.getElementById('loginPassword').value;
    if(!email || !pass) { alert("Bilgileri girin."); return; }
    signInWithEmailAndPassword(auth, email, pass)
    .then(() => {
        alert("Giriş Başarılı!");
        location.reload(); // Oturumun formlara yansıması için yenileme
    })
    .catch((error) => { alert("Giriş Başarısız."); });
}

window.logoutUser = function() {
    signOut(auth).then(() => { 
        if (window.location.href.indexOf('randevularim.html') > -1) {
            window.location.href = 'index.html';
        } else {
            location.reload(); 
        }
    });
}

// --- 4. VERİTABANI SENKRONİZASYONU ---
function syncUserToDB(userData) {
    return fetch('api/login_sync.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData)
    })
    .then(res => res.json())
    .then(data => {
        console.log("DB Sync OK:", data);
        return data; 
    })
    .catch(err => {
        console.error("Sync Error:", err);
        throw err; 
    });
}

function syncUserToDBFromObject(user) {
    let ad = "";
    let soyad = "";
    if (user.displayName) {
        const parts = user.displayName.split(' ');
        if (parts.length > 1) { soyad = parts.pop(); ad = parts.join(' '); } 
        else { ad = parts[0]; }
    }
    syncUserToDB({ uid: user.uid, email: user.email, ad: ad, soyad: soyad });
}

// --- GÜNLÜK LİMİT KONTROLÜ ---
async function checkDailyLimit(uid, date) {
    try {
        const response = await fetch('api/user_appointments.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ uid: uid })
        });
        const res = await response.json();
        
        if (res.status === 'success' && Array.isArray(res.data)) {
            const count = res.data.filter(app => app.randevu_tarihi === date).length;
            return count < 3;
        }
        return true; 
    } catch (error) {
        console.error("Limit kontrol hatası:", error);
        return true; 
    }
}

// --- 5. E-POSTA DOĞRULAMA & RANDEVU (MİSAFİR) ---

if(document.getElementById('recaptcha-container')) {
    window.recaptchaVerifier = new RecaptchaVerifier('recaptcha-container', { 'size': 'invisible' }, auth);
}

// E-Posta Kodu Gönder (MİSAFİR RANDEVU İÇİN)
window.emailKoduGonder = function() {
    const ad = document.getElementById('randevu_ad').value;
    const soyad = document.getElementById('randevu_soyad').value;
    const email = document.getElementById('randevu_email').value;
    const sifre = document.getElementById('randevu_sifre').value;
    const tel = document.getElementById('telefon').value;
    const tarih = document.getElementById('tarih').value;
    const saat = document.getElementById('saat').value;
    const hizmet = document.getElementById('hizmet_turu').value; // HİZMET KONTROLÜ

    if(!ad || !soyad || !email || !sifre || !tel || !tarih || !saat || !hizmet) {
        alert("Lütfen tüm alanları (Hizmet dahil) doldurun."); return;
    }

    if (!validateName(ad) || !validateName(soyad)) {
        alert("Ad ve Soyad alanlarında sadece harf kullanılabilir."); return;
    }

    fetch('api/send_email_code.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email })
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === 'success') {
            alert(data.message); 
            if(data.debug_code) alert("TEST KODU: " + data.debug_code); 
            
            document.getElementById('adim1').style.display = 'none';
            document.getElementById('dogrulamaAlani').style.display = 'block';
        } else {
            alert("Hata: " + data.message);
        }
    })
    .catch(err => alert("Mail sunucu hatası."));
}

window.koduOnayla = function() {
    const code = document.getElementById('verificationCode').value;
    if(!code) { alert("Kodu girin."); return; }

    fetch('api/verify_email_code.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: code })
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === 'success') {
            processGuestAppointment();
        } else {
            alert("Hata: " + data.message);
        }
    })
    .catch(err => alert("Doğrulama hatası."));
}

function processGuestAppointment() {
    const email = document.getElementById('randevu_email').value;
    const pass = document.getElementById('randevu_sifre').value;
    const ad = document.getElementById('randevu_ad').value;
    const soyad = document.getElementById('randevu_soyad').value;
    const tel = document.getElementById('telefon').value;
    const hizmet = document.getElementById('hizmet_turu').value; // HİZMET DEĞERİ

    createUserWithEmailAndPassword(auth, email, pass)
    .then((userCredential) => {
        const user = userCredential.user;
        return updateProfile(user, { displayName: ad + " " + soyad })
            .then(() => user);
    })
    .then((user) => {
        return syncUserToDB({ uid: user.uid, email: email, ad: ad, soyad: soyad })
            .then(() => user);
    })
    .then((user) => {
        // Hizmet türünü kaydetmeye gönderiyoruz
        return saveAppointmentPromise(user.uid, tel, hizmet);
    })
    .then(() => {
        return signInWithEmailAndPassword(auth, email, pass);
    })
    .then(() => {
        alert("Randevu ve Üyelik Oluşturuldu! Yönlendiriliyorsunuz...");
        window.location.href = 'randevularim.html';
    })
    .catch((error) => {
        if(error.code === 'auth/email-already-in-use') {
            handleExistingUser(email, pass, ad, soyad, tel, hizmet);
        } else {
            alert("İşlem hatası: " + error.message);
        }
    });
}

function handleExistingUser(email, pass, ad, soyad, tel, hizmet) {
    signInWithEmailAndPassword(auth, email, pass)
    .then((userCredential) => {
        const user = userCredential.user;
        syncUserToDB({ uid: user.uid, email: email, ad: ad, soyad: soyad })
        .then(() => {
            return saveAppointmentPromise(user.uid, tel, hizmet);
        })
        .then(() => {
            alert("Mevcut hesabınızla randevu oluşturuldu!");
            window.location.href = 'randevularim.html';
        });
    })
    .catch((err) => {
        alert("Bu e-posta kayıtlı ancak şifre yanlış. Lütfen giriş yapın.");
    });
}

// Giriş Yapmış Kullanıcı İçin Direkt Randevu
window.directAppointmentBook = function() {
    const user = auth.currentUser;
    let rawTel = document.getElementById('telefon').value;
    const hizmet = document.getElementById('hizmet_turu').value; // HİZMET DEĞERİ
    
    if(!user) { location.reload(); return; }
    if(!hizmet) { alert("Lütfen bir hizmet seçin."); return; }
    if(!rawTel || rawTel.length < 10) { alert("Lütfen telefon numaranızı girin."); return; }
    
    let cleanTel = rawTel.replace(/\D/g, ''); 
    if (cleanTel.startsWith('0')) cleanTel = cleanTel.substring(1);
    const formattedTel = '+90' + cleanTel;
    
    saveAppointmentPromise(user.uid, formattedTel, hizmet)
    .then(() => {
        alert("Randevunuz alındı!");
        window.location.href = 'randevularim.html';
    })
    .catch(err => alert("Hata: " + err.message));
}

// Promise Tabanlı Randevu Kaydı (GÜNCELLENDİ: HİZMET TÜRÜ)
function saveAppointmentPromise(uid, phone, hizmet) {
    return new Promise((resolve, reject) => {
        const tarih = document.getElementById('tarih').value;
        const saat = document.getElementById('saat').value;

        checkDailyLimit(uid, tarih).then(isAllowed => {
            if (!isAllowed) {
                const msg = "Üzgünüz, bir günde en fazla 3 randevu alabilirsiniz.";
                alert(msg);
                reject(new Error(msg));
                return;
            }

            const veri = {
                ad_soyad: document.getElementById('randevu_ad').value + " " + document.getElementById('randevu_soyad').value,
                telefon: phone,
                tarih: tarih,
                saat: saat,
                hizmet_turu: hizmet, // GÖNDERİLEN YENİ VERİ
                user_uid: uid
            };

            fetch('api/kaydet.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(veri)
            })
            .then(res => res.json())
            .then(data => {
                if(data.status === "success") resolve(data);
                else reject(new Error(data.message));
            })
            .catch(err => reject(err));
        });
    });
}

// --- RANDEVU İPTAL İŞLEMİ ---
window.cancelUserAppointment = function(randevuId) {
    if(!confirm("Randevunuzu iptal etmek istediğinize emin misiniz?")) return;

    fetch('api/cancel_appointment.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: randevuId, uid: currentUserUID })
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === 'success') {
            alert("Randevu iptal edildi.");
            loadUserAppointments(currentUserUID);
        } else {
            alert("Hata: " + data.message);
        }
    })
    .catch(err => alert("Bağlantı hatası."));
}

// --- 6. SAYFA YÜKLENME (GENEL + MANİFESTO & HARİTA) ---
document.addEventListener('DOMContentLoaded', () => {
    fetch('api/ayarlar.php')
    .then(res => res.json())
    .then(data => {
        // "Undefined" hatasını ve anlık renk kaybolmasını önlemek için varsayılanlar
        const settings = {
            site_basligi: data.site_basligi || "Gold Makas",
            ana_renk: data.ana_renk || "#c79c60",
            arka_plan: data.arka_plan || "#121212",
            hero_baslik: data.hero_baslik || "Tarzını Keşfet",
            hero_alt: data.hero_alt || "Profesyonel Hizmet"
        };

        document.title = settings.site_basligi;
        const root = document.documentElement;
        root.style.setProperty('--main-color', settings.ana_renk);
        root.style.setProperty('--bg-color', settings.arka_plan);

        setTextIfExists('headerLogo', settings.site_basligi);
        setTextIfExists('heroTitle', settings.hero_baslik);
        setTextIfExists('heroSub', settings.hero_alt);
        
        setTextIfExists('manifestoTitle', "Manifestomuz");
        setTextIfExists('manifestoText', data.manifesto_metin || "Felsefemiz yakında burada olacak.");
        const mImg = document.getElementById('manifestoImage');
        if(mImg && data.manifesto_resim) {
            mImg.src = data.manifesto_resim;
        }

        setTextIfExists('mapTitle', "Konumumuz");
        if(data.harita_iframe) {
            setHtmlIfExists('mapContainer', data.harita_iframe);
        } else {
            setHtmlIfExists('mapContainer', '<div style="display:flex; height:100%; align-items:center; justify-content:center; color:#555;">Konum bilgisi admin panelinden girilmemiş.</div>');
        }

        setTextIfExists('footerAdres', data.adres || "");
        setTextIfExists('footerIlce', data.adres_ilce || "");
        setTextIfExists('footerEmail', data.email_iletisim || "");
        setTextIfExists('footerTel', data.telefon || "");
        setTextIfExists('footerTitle', settings.site_basligi);
        setTextIfExists('workingHours', data.calisma_saatleri || "");
        
        const fbLink = document.getElementById('linkFacebook'); if(fbLink) fbLink.href = data.facebook_url || "#";
        const igLink = document.getElementById('linkInstagram'); if(igLink && data.instagram) igLink.href = "https://instagram.com/" + data.instagram.replace('@', '').trim();
        const ytLink = document.getElementById('linkYoutube'); if(ytLink) ytLink.href = data.youtube_url || "#";
    })
    .catch(err => {
        console.error("Ayarlar yüklenemedi, varsayılanlar kullanılıyor.");
        setTextIfExists('headerLogo', "GOLD MAKAS");
    });
    
    // YENİ: Hizmetleri Çek
    loadServices();

    const dateInput = document.getElementById('grafikTarih');
    if(dateInput) {
        const today = new Date().toISOString().split('T')[0];
        dateInput.value = today;
        const modalDate = document.getElementById('tarih');
        if(modalDate) {
            modalDate.value = today;
            modalDate.addEventListener('change', populateTimeSelect);
        }
        populateTimeSelect();
        renderAvailabilityChart();
    }
});

// --- HİZMETLERİ YÜKLE ---
function loadServices() {
    fetch('api/hizmetler.php')
    .then(res => res.json())
    .then(data => {
        const container = document.getElementById('services-container');
        if(container && data.length > 0) {
            container.innerHTML = ''; 
            data.forEach(hizmet => {
                let featuresHtml = '';
                if(hizmet.ozellikler) {
                    const features = hizmet.ozellikler.split(',');
                    featuresHtml = `<ul class="service-list">` + features.map(f => `<li>${f.trim()}</li>`).join('') + `</ul>`;
                }
                const cardHtml = `<div class="card"><i class="${hizmet.ikon}"></i><h3>${hizmet.baslik}</h3>${featuresHtml}<button onclick="scrollToAvailability()" class="price-btn">${hizmet.fiyat} - Randevu Al</button></div>`;
                container.innerHTML += cardHtml;
            });
        }
        const select = document.getElementById('hizmet_turu');
        if(select && data.length > 0) {
            select.innerHTML = '<option value="" disabled selected>Hizmet Seçiniz...</option>';
            data.forEach(hizmet => {
                const option = document.createElement('option');
                option.value = hizmet.baslik;
                option.innerText = hizmet.baslik;
                select.appendChild(option);
            });
        }
    })
    .catch(err => console.log("Hizmetler yüklenemedi."));
}

// --- YARDIMCI FONKSİYONLAR ---
function generateTimeSlots() {
    let slots = [];
    for (let i = 10; i < 20; i++) { slots.push(`${i}:00`); slots.push(`${i}:30`); }
    return slots;
}

function populateTimeSelect() {
    const select = document.getElementById('saat');
    const dateInput = document.getElementById('tarih');
    if(!select) return;
    
    select.innerHTML = '<option value="" disabled selected>Saat Seçin</option>';
    const slots = generateTimeSlots();
    
    let isToday = false;
    let isPast = false;

    if (dateInput && dateInput.value) {
        const selectedDateStr = dateInput.value;
        const now = new Date();
        const todayStr = now.toISOString().split('T')[0];
        if (selectedDateStr === todayStr) isToday = true;
        else if (selectedDateStr < todayStr) isPast = true;
    }
    
    if (isPast) return;

    const now = new Date();

    slots.forEach(time => {
        let shouldShow = true;
        if (isToday) {
            const [h, m] = time.split(':').map(Number);
            const slotDate = new Date();
            slotDate.setHours(h, m, 0, 0);
            
            if (slotDate < now) {
                shouldShow = false;
            }
        }
        
        if (shouldShow) {
            let option = document.createElement('option');
            option.value = time;
            option.innerText = time;
            select.appendChild(option);
        }
    });
}

window.renderAvailabilityChart = function() {
    const dateInputVal = document.getElementById('grafikTarih').value;
    const grid = document.getElementById('slotsGrid');
    if(!grid) return;
    
    grid.innerHTML = '<p style="color:white;">Kontrol ediliyor...</p>';

    fetch(`api/dolu_saatler.php?tarih=${dateInputVal}`)
    .then(res => res.json())
    .then(doluSaatler => {
        grid.innerHTML = ''; 
        const tumSaatler = generateTimeSlots();
        const simdi = new Date();
        const secilenTarihParcalari = dateInputVal.split('-'); 
        const secilenTarihObj = new Date(secilenTarihParcalari[0], secilenTarihParcalari[1]-1, secilenTarihParcalari[2]);
        const bugunTarihObj = new Date();
        bugunTarihObj.setHours(0,0,0,0); 

        tumSaatler.forEach(saat => {
            const div = document.createElement('div');
            div.className = 'time-slot';
            div.innerText = saat;
            let gecmisZamanMi = false;

            if (secilenTarihObj < bugunTarihObj) {
                gecmisZamanMi = true;
            }
            else if (secilenTarihObj.getTime() === bugunTarihObj.getTime()) {
                const [h, m] = saat.split(':').map(Number);
                const randevuZamani = new Date();
                randevuZamani.setHours(h, m, 0, 0);
                if (randevuZamani < simdi) {
                    gecmisZamanMi = true;
                }
            }

            if(doluSaatler.includes(saat) || gecmisZamanMi) {
                div.classList.add('full'); 
                div.title = gecmisZamanMi ? "Geçmiş zaman" : "Bu saat dolu";
                div.style.cursor = "not-allowed";
                div.style.opacity = "0.5";
            } else {
                div.onclick = () => {
                    const modalDateInput = document.getElementById('tarih');
                    const modalTimeSelect = document.getElementById('saat');
                    if(modalDateInput) modalDateInput.value = dateInputVal;
                    populateTimeSelect();
                    if(modalTimeSelect) modalTimeSelect.value = saat;
                    if(window.openModal) window.openModal('randevuModal');
                    else document.getElementById('randevuModal').style.display = 'block';
                };
                div.title = "Randevu al";
            }
            grid.appendChild(div);
        });
    });
}

function loadUserAppointments(uid) {
    const table = document.getElementById('appointmentsTable');
    const tbody = document.getElementById('appointmentsBody');
    const loading = document.getElementById('loading');
    const empty = document.getElementById('emptyMessage');

    if(!table || !tbody) return;

    fetch('api/user_appointments.php', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ uid: uid }) })
    .then(res => res.json())
    .then(response => {
        if(loading) loading.style.display = 'none';
        
        if (response.status === 'success' && response.data.length > 0) {
            table.style.display = 'block'; 
            if(empty) empty.style.display = 'none';
            tbody.innerHTML = '';
            
            const now = new Date();

            response.data.forEach(item => {
                const dateObj = new Date(item.randevu_tarihi);
                const dateFormatted = dateObj.toLocaleDateString('tr-TR');
                const randevuZamaniStr = item.randevu_tarihi + 'T' + item.randevu_saati + ':00';
                const randevuZamani = new Date(randevuZamaniStr);
                const farkMs = randevuZamani - now;

                let kalanSureText = "";
                let durumBadge = "";
                let islemButonu = "";
                let isPast = false;

                if (farkMs < 0) {
                    isPast = true;
                    kalanSureText = "<span style='color:#777;'>Süresi Doldu</span>";
                    durumBadge = "<span class='status-badge' style='color:#777; border-color:#555;'>Tamamlandı</span>";
                    islemButonu = "<span style='color:#555; font-size:0.8rem;'>İşlem Yok</span>";
                } else {
                    const gun = Math.floor(farkMs / (1000 * 60 * 60 * 24));
                    const saat = Math.floor((farkMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    const dakika = Math.floor((farkMs % (1000 * 60 * 60)) / (1000 * 60));
                    
                    if (gun > 0) kalanSureText = `${gun} Gün ${saat} Saat`;
                    else if (saat > 0) kalanSureText = `${saat} Saat ${dakika} Dk`;
                    else kalanSureText = `${dakika} Dakika`;

                    kalanSureText = `<span style="color:var(--main-color); font-weight:bold;">${kalanSureText}</span>`;
                    durumBadge = "<span class='status-badge status-active'>Aktif</span>";
                    islemButonu = `<button onclick="cancelUserAppointment(${item.id})" class="btn-cancel" style="border:1px solid #cc3333; color:#cc3333; background:transparent; padding:5px 10px; border-radius:5px; cursor:pointer;" title="İptal Et"><i class="fa-solid fa-xmark"></i> İptal</button>`;
                }
                
                const hizmetAdi = item.hizmet_turu || "Genel Hizmet";

                const row = `
                    <tr style="${isPast ? 'opacity:0.5;' : ''}">
                        <td style="color:#fff;">${dateFormatted} <br><small style="color:#777">${item.randevu_saati}</small></td>
                        <td>${kalanSureText}</td>
                        <td style="font-size:0.95rem; color:#ddd;">${hizmetAdi}</td>
                        <td>${durumBadge}</td>
                        <td>${islemButonu}</td>
                    </tr>
                `;
                tbody.innerHTML += row;
            });
        } else {
            table.style.display = 'none';
            if(empty) empty.style.display = 'block';
        }
    }).catch(err => { if(loading) loading.innerText = "Veri alınamadı."; });
}

window.newsletterSubscribe = function() {
    const container = document.querySelector('.newsletter-box');
    if(!container) return;
    const input = container.querySelector('input');
    const email = input.value;

    if (!email || !email.includes('@')) {
        alert("Lütfen geçerli bir e-posta adresi girin."); return;
    }

    fetch('api/subscribe.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email })
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === 'success') {
            alert("🎉 " + data.message);
            input.value = "";
        } else {
            alert("⚠️ " + data.message);
        }
    })
    .catch(err => alert("Bağlantı hatası."));
}