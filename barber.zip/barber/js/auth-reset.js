import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-app.js";
import { getAuth, sendPasswordResetEmail } from "https://www.gstatic.com/firebasejs/9.22.0/firebase-auth.js";

// --- FIREBASE KONFİGÜRASYONU ---
// (Mevcut projenizle aynı olmalı)
const firebaseConfig = {
  apiKey: "AIzaSyAJOq9Y8C1S5AWP79oLbUbWc25IDKHzAcg",
  authDomain: "barber-86433.firebaseapp.com",
  projectId: "barber-86433",
  storageBucket: "barber-86433.firebasestorage.app",
  messagingSenderId: "1032802718004",
  appId: "1:1032802718004:web:d2204ed66d9544adf45561",
  measurementId: "G-0925B75DDT"
};

// Firebase'i bu dosya için başlat
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
auth.languageCode = 'tr'; // E-postanın Türkçe gitmesi için

/**
 * Şifre Sıfırlama E-postası Gönder (DB Kontrollü)
 */
window.sendResetLink = function() {
    const emailInput = document.getElementById('forgotEmail');
    const btn = document.getElementById('btnResetPass');
    const email = emailInput.value;

    // 1. Basit Doğrulama
    if (!email || !email.includes('@')) {
        alert("Lütfen geçerli bir e-posta adresi girin.");
        return;
    }

    // 2. Butonu Kilitle
    const originalText = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Kontrol Ediliyor...';

    // 3. Veritabanı Kontrolü (Önce API'ye sor)
    fetch('api/check_email.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email })
    })
    .then(res => res.json())
    .then(data => {
        if (data.status === 'exists') {
            // E-posta veritabanında VAR -> Firebase'e gönder
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Gönderiliyor...';
            
            return sendPasswordResetEmail(auth, email)
                .then(() => {
                    alert("✅ Şifre sıfırlama bağlantısı e-posta adresinize gönderildi! Lütfen spam klasörünüzü de kontrol edin.");
                    if(window.closeModal) window.closeModal('forgotModal');
                    else document.getElementById('forgotModal').style.display = 'none';
                    emailInput.value = "";
                });
        } else {
            // E-posta veritabanında YOK -> Hata ver ve dur
            throw new Error("Bu e-posta adresi sistemimizde kayıtlı değil.");
        }
    })
    .catch((error) => {
        // Hata Yönetimi
        let errorMessage = error.message;
        
        // Firebase hatalarını yakala (eğer API geçerse ama Firebase hata verirse)
        if (error.code === 'auth/user-not-found') errorMessage = "Bu e-posta adresiyle kayıtlı bir kullanıcı bulunamadı.";
        else if (error.code === 'auth/invalid-email') errorMessage = "Geçersiz e-posta formatı.";

        alert("❌ Hata: " + errorMessage);
    })
    .finally(() => {
        // Butonu eski haline getir
        btn.disabled = false;
        btn.innerHTML = originalText;
    });
}